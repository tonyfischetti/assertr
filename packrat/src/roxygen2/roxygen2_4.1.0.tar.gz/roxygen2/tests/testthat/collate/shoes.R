#' @include socks.R
#' @include undershorts.R
#' @include pants.R
NULL

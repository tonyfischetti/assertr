cbind_list <- function(...){
  cbind_list__impl(environment())  
}


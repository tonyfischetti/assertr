#' The dplyr package.
#'
#' @docType package
#' @name dplyr
#' @useDynLib dplyr
#' @import assertthat
#' @importFrom utils head tail
#' @importFrom Rcpp cppFunction Rcpp.plugin.maker
NULL
